var httInt;
var sizeInt;
var listInt;
httInt = new XMLHttpRequest();
httInt.open("POST","PHP/getInterests.php",true);
httInt.onload = listInterest;
httInt.send();
var interestForm = document.getElementById("formInterest");

function listInterest(ev)
{
    listInt = JSON.parse(httInt.responseText);
    sizeInt = listInt.length;

    for(var i =0; i<sizeInt;i++)
    {
        var check = document.createElement("input");
        check.setAttribute("type","checkbox");
        check.setAttribute("name","checkInt");
        check.setAttribute("id","interestCheck"+i);   
        check.setAttribute("value",listInt[i].interest_id);
        var intName =  document.createTextNode(listInt[i].interest_name);
        var enter = document.createElement("P");
        interestForm.appendChild(check);  
        interestForm.appendChild(intName); 
        interestForm.appendChild(enter); 
    }
}

function addInterest()
{
    var ii = 0
    var count = 0;

    var intData=[];

    while(ii<sizeInt)
    {
        var checkB = document.getElementById("interestCheck"+ii);
        if(checkB.checked)
        {
                intData[count]=checkB.value;
                count++;
        }
        ii++;
    }

    var httInta;
    httInta = new XMLHttpRequest();
    httInta.open("POST","PHP/saveInterests.php",true);
    var dataInterest={};
    dataInterest.intID=intData;
    dataInterest.length=intData.length
    httInta.send(JSON.stringify(dataInterest));
    
}