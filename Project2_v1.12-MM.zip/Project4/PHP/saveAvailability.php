<?php
    session_start();
    require_once "default.php"
?>
<?php
    $req = file_get_contents('php://input');

    $req_obj = json_decode($req);

    $userid = logged_in_user();
    $conn = mysqli_connect($DB_HOST,$DB_USER,$DB_PASSWORD,$DB_NAME);
    $query= "UPDATE Availability SET sunday=?,monday=?,tuesday=?,wednesday=?,thursday=?,friday=?,saturday=? wHERE user_id=?;";
    $sun = $req_obj->sun;
    $mon = $req_obj->mon;
    $tues = $req_obj->tues;
    $wed = $req_obj->wed;
    $thurs = $req_obj->thurs;
    $fri = $req_obj->fri;
    $sat = $req_obj->sat;

        $stmt = mysqli_prepare($conn, $query);
        mysqli_stmt_bind_param($stmt,"dddddddd",$sun,$mon,$tues,$wed,$thurs,$fri,$sat,$userid);
        $success = mysqli_stmt_execute($stmt);
        $results = mysqli_stmt_get_result($stmt);

    

        //Inform the client that we are sending back JSON    
    header("Content-Type: application/json");
    //Encodes and sends it back
    echo json_encode($req_obj);
?>