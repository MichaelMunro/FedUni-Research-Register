loadAvailability();
httLoad;
function loadAvailability()
{
    httLoad= new XMLHttpRequest();
    httLoad.open("POST","PHP/getAvailability.php",true);
    httLoad.onload=listAvailability;
    httLoad.send();
}

function listAvailability(ev)
{
    console.log("Hey we're lsiting avial");
    var times = JSON.parse(httLoad.responseText);
    console.log("The time is" +times.sunday);
    document.getElementById('sunday').value= times.sunday;
    document.getElementById('monday').value=times.monday;
    document.getElementById('tuesday').value=times.tuesday;
    document.getElementById('wednesday').value=times.wednesday;
    document.getElementById('thursday').value=times.thursday;
    document.getElementById('friday').value=times.friday;
    document.getElementById('saturday').value=times.saturday;

}

function addAvailability()
{
    var sun = document.getElementById('sunday').value;
    var mon = document.getElementById('monday').value;
    var tues = document.getElementById('tuesday').value;
    var wed = document.getElementById('wednesday').value;
    var thurs = document.getElementById('thursday').value;
    var fri = document.getElementById('friday').value;
    var sat = document.getElementById('saturday').value;

    var httAvail = new XMLHttpRequest();
    var availData = {};
    availData.sun = sun;
    availData.mon = mon;
    availData.tues = tues;
    availData.wed = wed;
    availData.thurs = thurs;
    availData.fri = fri;
    availData.sat = sat;
    httAvail.open("POST", "PHP/saveAvailability.php",true);
    httAvail.send(JSON.stringify(availData));
}