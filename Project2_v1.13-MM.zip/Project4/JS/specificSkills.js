            var htt;
            var sizes;
            var lists;
            var sel = document.getElementById('category');
            console.log("LOOKING");
            getList("Psychology");
            sel.addEventListener('change',function(ev)
            {
                console.log("This was " +sel.options[sel.selectedIndex].text);
                
                getList(sel.options[sel.selectedIndex].text);
            },false)

            function clear()
            {
                for(var i = 0; i<sizes;i++)
                {

                    var myNode = document.getElementById("form10");
                    while (myNode.firstChild) {
                        myNode.removeChild(myNode.firstChild);
    }


                }
            }
            function getList(d)
            {
                clear();
                htt = new XMLHttpRequest();
                console.log(d);
                r.category = d;
                htt.open("POST","PHP/getSpecific.php",true);
                htt.onload= listy;
                htt.send(JSON.stringify(r));
            } 
            var x = document.getElementById("form10");
            function listy(ev)
            {


            }


            function addSpecificSkills()
            {
             

                var htts;
                htts = new XMLHttpRequest();
                htts.open("POST","PHP/sign.php",true);
                var hID = {};
                hID.checkData= array; 
                hID.skillData=arr;
                hID.lengths =array.length;
                htts.send(JSON.stringify(hID));
                alert(g+ " Skill(s) have been added");
            }
